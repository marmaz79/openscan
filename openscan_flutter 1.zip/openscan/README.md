# OpenScan

Scanner di documenti per Android e iOS: gratuito, offline, senza abbonamenti, account o pubblicità.

## Funzioni
- Scansione con rilevamento automatico dei bordi e ritaglio, multipagina
- Importazione dalla galleria con ritaglio manuale
- Filtri (migliora, grigi, bianco e nero), rotazione, ripristino dell'originale
- OCR sul dispositivo: latino, cinese, giapponese, coreano, devanagari (ML Kit) e arabo (Tesseract), con modalità Automatico
- Ricerca nel testo riconosciuto, modifica ed esportazione in .txt
- Collage: 2, 4, 6 o 9 pagine per foglio A4 in un nuovo documento (menu ⋮ → Crea collage)
- PDF multipagina A4 **senza filigrana**, oppure condivisione come immagini
- Tutto resta sul dispositivo

## Requisiti
Flutter 3.24 o superiore e un dispositivo reale (la fotocamera non funziona su molti emulatori).
Versioni minime: Android 7.0 (API 24), iOS 15.5.

## Avvio
Dalla cartella del progetto:

```bash
flutter create --org com.example --project-name openscan --platforms android,ios .
flutter pub get
dart tool/setup_platforms.dart
flutter run --release
```

- `flutter create` non sovrascrive `lib/` né `pubspec.yaml`; se lo facesse, ricopiali dallo zip.
- `tool/setup_platforms.dart` configura da solo i file nativi (è sicuro rilanciarlo):
  - **Android**: `minSdk` 24, permesso fotocamera, librerie ML Kit per cinese/giapponese/coreano/devanagari. *Senza queste librerie l'OCR di quegli alfabeti va in crash.*
  - **iOS**: piattaforma 15.5, pod ML Kit aggiuntivi, esclusione di armv7, `NSCameraUsageDescription`.
- Su iOS, dopo la configurazione: `cd ios && pod install --repo-update`.

## Arabo su iOS (passaggio manuale)
L'OCR arabo usa Tesseract, un plugin poco mantenuto. Su iOS può dare l'errore
"Initialization of SwiftyTesseract has failed". Soluzione: in Xcode, trascina la cartella
`assets/tessdata` dentro il gruppo **Runner** scegliendo *Create folder references*.
Su Android non serve nulla.

Se non ti serve l'arabo, puoi toglierlo: rimuovi `flutter_tesseract_ocr` e le due voci
`assets/tessdata*` da `pubspec.yaml`, e sostituisci il contenuto di `lib/services/arabic_ocr.dart`
con `Future<String> recognizeArabic(String p) async => throw UnsupportedError('Arabo non disponibile');`.

## Note sull'OCR
- In modalità *Automatico* l'app prova tutti gli alfabeti ML Kit e sceglie il più coerente; l'arabo
  viene tentato solo se non trova nulla. Se conosci la lingua, sceglierla a mano è più veloce e preciso.
- Tesseract rende meno di ML Kit su foto storte o poco luminose: per l'arabo usa scansioni ben
  ritagliate e il filtro "Migliora" o "Bianco e nero".
- Altre lingue Tesseract: aggiungi `xxx.traineddata` in `assets/tessdata/`, elencalo in
  `assets/tessdata_config.json` ed estendi `OcrLang` e `arabic_ocr.dart`.

## Struttura
- `lib/screens/home_screen.dart`: elenco, ricerca, scansione, importazione
- `lib/screens/doc_screen.dart`: visualizzatore, filtri, OCR, collage, esportazione
- `lib/services/`: archivio locale, scanner, filtri e collage, OCR, PDF
- `tool/setup_platforms.dart`: configurazione automatica di Android e iOS
