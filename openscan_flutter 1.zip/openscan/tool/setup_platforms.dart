// Configura i progetti Android/iOS generati da `flutter create`.
//
//   dart run tool/setup_platforms.dart [cartella_progetto]
//
// È idempotente: puoi rilanciarlo senza duplicare nulla.
//  - Android: minSdk 24, permesso CAMERA, librerie ML Kit per cinese/giapponese/
//    coreano/devanagari (senza, quegli OCR vanno in crash).
//  - iOS: piattaforma 15.5, pod ML Kit extra, esclusione armv7, NSCameraUsageDescription.
import 'dart:io';

const _minAndroid = 24;
const _iosVersion = '15.5';
const _mlkitAndroid = '16.0.0';
const _mlkitPods = '~> 7.0.0';
const _scripts = ['chinese', 'devanagari', 'japanese', 'korean'];

late final String root;
final done = <String>[];
final warn = <String>[];

File? _first(List<String> rels) {
  for (final r in rels) {
    final f = File('$root/$r');
    if (f.existsSync()) return f;
  }
  return null;
}

void _android() {
  final gradle = _first([
    'android/app/build.gradle.kts',
    'android/app/build.gradle',
  ]);
  if (gradle == null) {
    warn.add(
      'android/app/build.gradle(.kts) non trovato: esegui prima `flutter create`.',
    );
  } else {
    final kts = gradle.path.endsWith('.kts');
    var s = gradle.readAsStringSync();
    final before = s;

    final minRe = RegExp(
      r'minSdk(?:Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)',
    );
    if (!minRe.hasMatch(s)) {
      warn.add(
        'minSdk non trovato in ${gradle.path}: impostalo a $_minAndroid a mano.',
      );
    } else {
      s = s.replaceFirstMapped(minRe, (m) {
        final v = m[1]!;
        final n = int.tryParse(v);
        return (n == null || n < _minAndroid) ? 'minSdk = $_minAndroid' : m[0]!;
      });
    }

    if (!s.contains('text-recognition-chinese')) {
      final lines = _scripts
          .map(
            (l) => kts
                ? '    implementation("com.google.mlkit:text-recognition-$l:$_mlkitAndroid")'
                : "    implementation 'com.google.mlkit:text-recognition-$l:$_mlkitAndroid'",
          )
          .join('\n');
      final dep = RegExp(r'^dependencies\s*\{', multiLine: true);
      s = dep.hasMatch(s)
          ? s.replaceFirstMapped(dep, (m) => '${m[0]}\n$lines')
          : '$s\ndependencies {\n$lines\n}\n';
    }
    if (s != before) {
      gradle.writeAsStringSync(s);
      done.add('Android: ${gradle.path} (minSdk + librerie ML Kit)');
    }
  }

  final manifest = _first(['android/app/src/main/AndroidManifest.xml']);
  if (manifest != null) {
    var s = manifest.readAsStringSync();
    if (!s.contains('android.permission.CAMERA')) {
      s = s.replaceFirst(
        '<application',
        '<uses-permission android:name="android.permission.CAMERA"/>\n    <application',
      );
      manifest.writeAsStringSync(s);
      done.add('Android: permesso CAMERA nel manifest');
    }
  } else {
    warn.add('AndroidManifest.xml non trovato.');
  }
}

void _ios() {
  final podfile = _first(['ios/Podfile']);
  if (podfile == null) {
    warn.add('ios/Podfile non trovato: esegui prima `flutter create`.');
  } else {
    var s = podfile.readAsStringSync();
    final before = s;

    s = s.replaceFirst(
      RegExp(r'^[ \t]*#?[ \t]*platform :ios,.*$', multiLine: true),
      "platform :ios, '$_iosVersion'",
    );

    if (!s.contains('TextRecognitionChinese')) {
      final pods = _scripts
          .map((l) {
            final name = l[0].toUpperCase() + l.substring(1);
            return "  pod 'GoogleMLKit/TextRecognition$name', '$_mlkitPods'";
          })
          .join('\n');
      final re = RegExp(
        r'^([ \t]*flutter_install_all_ios_pods.*)$',
        multiLine: true,
      );
      if (re.hasMatch(s)) {
        s = s.replaceFirstMapped(re, (m) => '${m[1]}\n$pods');
      } else {
        warn.add(
          'flutter_install_all_ios_pods non trovato nel Podfile: aggiungi i pod ML Kit a mano.',
        );
      }
    }

    if (!s.contains('EXCLUDED_ARCHS')) {
      final re = RegExp(
        r'^post_install do \|installer\|[ \t]*$',
        multiLine: true,
      );
      if (re.hasMatch(s)) {
        s = s.replaceFirstMapped(
          re,
          (m) => '''${m[0]}
  installer.pods_project.build_configurations.each do |config|
    config.build_settings["EXCLUDED_ARCHS[sdk=*]"] = "armv7"
  end''',
        );
        s = s.replaceFirst(
          RegExp(
            r'^([ \t]*)flutter_additional_ios_build_settings\(target\)[ \t]*$',
            multiLine: true,
          ),
          "    flutter_additional_ios_build_settings(target)\n"
          "    target.build_configurations.each do |config|\n"
          "      if config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'].to_f < $_iosVersion\n"
          "        config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '$_iosVersion'\n"
          "      end\n"
          "    end",
        );
      } else {
        warn.add(
          'post_install non trovato nel Podfile: escludi armv7 a mano (vedi README).',
        );
      }
    }
    if (s != before) {
      podfile.writeAsStringSync(s);
      done.add(
        'iOS: ios/Podfile (piattaforma $_iosVersion, pod ML Kit, armv7)',
      );
    }
  }

  final pbx = _first(['ios/Runner.xcodeproj/project.pbxproj']);
  if (pbx != null) {
    final s = pbx.readAsStringSync();
    final re = RegExp(r'IPHONEOS_DEPLOYMENT_TARGET = (\d+(?:\.\d+)?);');
    final out = s.replaceAllMapped(re, (m) {
      final v = double.tryParse(m[1]!) ?? 0;
      return v < double.parse(_iosVersion)
          ? 'IPHONEOS_DEPLOYMENT_TARGET = $_iosVersion;'
          : m[0]!;
    });
    if (out != s) {
      pbx.writeAsStringSync(out);
      done.add('iOS: deployment target $_iosVersion in project.pbxproj');
    }
  }

  final plist = _first(['ios/Runner/Info.plist']);
  if (plist != null) {
    var s = plist.readAsStringSync();
    if (!s.contains('NSCameraUsageDescription')) {
      final i = s.lastIndexOf('</dict>');
      if (i >= 0) {
        s =
            '${s.substring(0, i)}'
            '\t<key>NSCameraUsageDescription</key>\n'
            '\t<string>Serve per scansionare i documenti.</string>\n'
            '${s.substring(i)}';
        plist.writeAsStringSync(s);
        done.add('iOS: NSCameraUsageDescription in Info.plist');
      }
    }
  } else {
    warn.add('ios/Runner/Info.plist non trovato.');
  }
}

void main(List<String> args) {
  root = args.isNotEmpty ? args.first : '.';
  _android();
  _ios();
  if (done.isEmpty && warn.isEmpty) {
    stdout.writeln('Niente da fare: i progetti sono già configurati.');
  }
  for (final d in done) {
    stdout.writeln('✔ $d');
  }
  for (final w in warn) {
    stdout.writeln('⚠ $w');
  }
  stdout.writeln(
    '\nPassaggio manuale rimasto (solo iOS + arabo): vedi README, sezione "Arabo su iOS".',
  );
  if (warn.isNotEmpty) exitCode = 1;
}
