/// Lingue/alfabeti supportati dall'OCR.
enum OcrLang {
  auto('Automatico'),
  latin('Latino (it, en, es, fr, de…)'),
  chinese('中文 Cinese'),
  japanese('日本語 Giapponese'),
  korean('한국어 Coreano'),
  devanagari('देवनागरी Hindi / Devanagari'),
  arabic('العربية Arabo');

  const OcrLang(this.label);
  final String label;
}

class ScanDoc {
  ScanDoc({
    required this.id,
    required this.name,
    required this.created,
    required this.pages,
    this.ocrText = '',
    this.ocrLang = OcrLang.auto,
  });

  final String id;
  String name;
  final DateTime created;

  /// Nomi dei file immagine dentro la cartella del documento.
  List<String> pages;
  String ocrText;
  OcrLang ocrLang;

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'created': created.toIso8601String(),
    'pages': pages,
    'ocrText': ocrText,
    'ocrLang': ocrLang.name,
  };

  factory ScanDoc.fromJson(Map<String, dynamic> j) => ScanDoc(
    id: j['id'] as String,
    name: j['name'] as String,
    created: DateTime.parse(j['created'] as String),
    pages: List<String>.from(j['pages'] as List),
    ocrText: (j['ocrText'] as String?) ?? '',
    ocrLang: OcrLang.values.firstWhere(
      (l) => l.name == j['ocrLang'],
      orElse: () => OcrLang.auto,
    ),
  );
}
