import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

void main() => runApp(const OpenScanApp());

class OpenScanApp extends StatelessWidget {
  const OpenScanApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF1E88E5);
    return MaterialApp(
      title: 'OpenScan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: seed, useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: seed,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
