import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/scan_doc.dart';
import 'repository.dart';

String _safe(String s) => s.replaceAll(RegExp(r'[^\w\- ]'), '_');

/// PDF multipagina A4, SENZA filigrana.
Future<File> buildPdf(Repository repo, ScanDoc d) async {
  final pdf = pw.Document(title: d.name);
  for (var i = 0; i < d.pages.length; i++) {
    final image = pw.MemoryImage(await repo.pageFile(d, i).readAsBytes());
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(
          image,
          width: PdfPageFormat.a4.width,
          height: PdfPageFormat.a4.height,
          fit: pw.BoxFit.contain,
        ),
      ),
    );
  }
  final tmp = await getTemporaryDirectory();
  final f = File(p.join(tmp.path, '${_safe(d.name)}.pdf'));
  await f.writeAsBytes(await pdf.save());
  return f;
}

Future<File> buildTxt(ScanDoc d) async {
  final tmp = await getTemporaryDirectory();
  final f = File(p.join(tmp.path, '${_safe(d.name)}.txt'));
  await f.writeAsString(d.ocrText);
  return f;
}
