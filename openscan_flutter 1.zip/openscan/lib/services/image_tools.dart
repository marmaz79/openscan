import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as im;

enum ScanFilter { auto, gray, bw }

Uint8List _job(List<Object> a) {
  final bytes = a[0] as Uint8List;
  final mode = a[1] as int; // 0 auto, 1 gray, 2 bw, 3 rotate
  var img = im.bakeOrientation(im.decodeImage(bytes)!);
  switch (mode) {
    case 0:
      img = im.adjustColor(
        img,
        contrast: 1.25,
        brightness: 1.05,
        saturation: 1.1,
      );
      break;
    case 1:
      img = im.adjustColor(im.grayscale(img), contrast: 1.2);
      break;
    case 2:
      img = im.adjustColor(im.grayscale(img), contrast: 2.2, brightness: 1.1);
      break;
    case 3:
      img = im.copyRotate(img, angle: 90);
      break;
  }
  return Uint8List.fromList(im.encodeJpg(img, quality: 90));
}

Future<void> _backupOnce(File f) async {
  final orig = File('${f.path}.orig');
  if (!await orig.exists()) await f.copy(orig.path);
}

Future<void> applyFilter(File f, ScanFilter filter) async {
  await _backupOnce(f);
  final out = await compute(_job, <Object>[
    await f.readAsBytes(),
    filter.index,
  ]);
  await f.writeAsBytes(out);
}

Future<void> rotate90(File f) async {
  await _backupOnce(f);
  final out = await compute(_job, <Object>[await f.readAsBytes(), 3]);
  await f.writeAsBytes(out);
}

Future<void> restoreOriginal(File f) async {
  final orig = File('${f.path}.orig');
  if (await orig.exists()) await orig.copy(f.path);
}

// ───────────────────────── Collage ─────────────────────────

class CollageLayout {
  const CollageLayout(this.cols, this.rows);
  final int cols, rows;
  int get perSheet => cols * rows;
}

const collageLayouts = [
  CollageLayout(1, 2),
  CollageLayout(2, 2),
  CollageLayout(2, 3),
  CollageLayout(3, 3),
];

/// Compone fino a cols*rows immagini su un foglio A4 (200 dpi), centrate nelle celle.
Uint8List _collageJob(List<Object> a) {
  final paths = (a[0] as List).cast<String>();
  final cols = a[1] as int;
  final rows = a[2] as int;
  const w = 1654, h = 2339, margin = 60, gap = 30;

  final canvas = im.Image(width: w, height: h);
  im.fill(canvas, color: im.ColorRgb8(255, 255, 255));
  final cellW = (w - 2 * margin - gap * (cols - 1)) ~/ cols;
  final cellH = (h - 2 * margin - gap * (rows - 1)) ~/ rows;

  for (var i = 0; i < paths.length; i++) {
    final decoded = im.decodeImage(File(paths[i]).readAsBytesSync());
    if (decoded == null) continue;
    final src = im.bakeOrientation(decoded);
    final scale = math.min(cellW / src.width, cellH / src.height);
    final tw = (src.width * scale).round();
    final th = (src.height * scale).round();
    final small = im.copyResize(
      src,
      width: tw,
      height: th,
      interpolation: im.Interpolation.average,
    );
    final x = margin + (i % cols) * (cellW + gap) + (cellW - tw) ~/ 2;
    final y = margin + (i ~/ cols) * (cellH + gap) + (cellH - th) ~/ 2;
    im.compositeImage(canvas, small, dstX: x, dstY: y);
  }
  return Uint8List.fromList(im.encodeJpg(canvas, quality: 90));
}

/// Raggruppa le pagine in fogli A4 e salva un JPG per foglio in [outDir].
Future<List<File>> buildCollages(
  List<String> pagePaths,
  CollageLayout layout,
  Directory outDir,
) async {
  final files = <File>[];
  for (var i = 0; i < pagePaths.length; i += layout.perSheet) {
    final group = pagePaths.sublist(
      i,
      math.min(i + layout.perSheet, pagePaths.length),
    );
    final bytes = await compute(_collageJob, <Object>[
      group,
      layout.cols,
      layout.rows,
    ]);
    final f = File('${outDir.path}/collage_${files.length + 1}.jpg');
    await f.writeAsBytes(bytes);
    files.add(f);
  }
  return files;
}
