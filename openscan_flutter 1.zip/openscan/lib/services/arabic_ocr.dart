import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';

/// L'arabo non è supportato da ML Kit: si usa Tesseract (modello in assets/tessdata).
Future<String> recognizeArabic(String imagePath) {
  return FlutterTesseractOcr.extractText(
    imagePath,
    language: 'ara',
    args: {'psm': '4', 'preserve_interword_spaces': '1'},
  );
}
