import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../models/scan_doc.dart';

/// Archivio locale: ogni documento è una cartella con le pagine (JPG) e meta.json.
class Repository {
  Repository._(this.root);
  final Directory root;

  static Future<Repository> open() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'scans'));
    await dir.create(recursive: true);
    return Repository._(dir);
  }

  Directory docDir(ScanDoc d) => Directory(p.join(root.path, d.id));
  File pageFile(ScanDoc d, int i) => File(p.join(docDir(d).path, d.pages[i]));

  Future<List<ScanDoc>> all() async {
    final out = <ScanDoc>[];
    await for (final e in root.list()) {
      if (e is! Directory) continue;
      final meta = File(p.join(e.path, 'meta.json'));
      if (!await meta.exists()) continue;
      try {
        out.add(ScanDoc.fromJson(jsonDecode(await meta.readAsString())));
      } catch (_) {
        /* meta corrotto: ignora */
      }
    }
    out.sort((a, b) => b.created.compareTo(a.created));
    return out;
  }

  Future<void> save(ScanDoc d) async {
    await docDir(d).create(recursive: true);
    await File(p.join(docDir(d).path, 'meta.json'))
        .writeAsString(jsonEncode(d.toJson()));
  }

  Future<ScanDoc> create(List<String> sourcePaths) async {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final d = ScanDoc(
      id: const Uuid().v4(),
      name:
          'Scansione ${two(now.day)}-${two(now.month)}-${now.year} ${two(now.hour)}.${two(now.minute)}',
      created: now,
      pages: [],
    );
    for (final s in sourcePaths) {
      await addPage(d, s);
    }
    await save(d);
    return d;
  }

  Future<void> addPage(ScanDoc d, String sourcePath) async {
    await docDir(d).create(recursive: true);
    final name = 'p_${const Uuid().v4()}.jpg';
    await File(sourcePath).copy(p.join(docDir(d).path, name));
    d.pages.add(name);
  }

  Future<void> removePage(ScanDoc d, int i) async {
    final f = pageFile(d, i);
    final orig = File('${f.path}.orig');
    if (await f.exists()) await f.delete();
    if (await orig.exists()) await orig.delete();
    d.pages.removeAt(i);
  }

  Future<void> delete(ScanDoc d) async {
    final dir = docDir(d);
    if (await dir.exists()) await dir.delete(recursive: true);
  }
}
