import 'package:cunning_document_scanner/cunning_document_scanner.dart';

/// Apre lo scanner nativo (fotocamera con rilevamento bordi, oppure galleria con
/// ritaglio manuale). Restituisce i percorsi delle immagini, o null se annullato.
Future<List<String>?> pickPages({bool galleryOnly = false}) {
  return CunningDocumentScanner.getPictures(
    scannerSource: galleryOnly
        ? ScannerSource.gallery
        : ScannerSource.cameraAndGallery,
    // Su iOS il default è PNG (file enormi): meglio JPEG.
    iosScannerOptions: IosScannerOptions(
      imageFormat: IosImageFormat.jpg,
      jpgCompressionQuality: 0.85,
    ),
  );
}
