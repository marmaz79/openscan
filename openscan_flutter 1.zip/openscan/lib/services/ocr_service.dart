import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

import '../models/scan_doc.dart';
import 'arabic_ocr.dart';
import 'repository.dart';

// Intervalli Unicode usati per stimare quale alfabeto è presente nel testo.
final _reLatin = RegExp(r'[A-Za-z\u00C0-\u024F]');
final _reHan = RegExp(r'[\u4E00-\u9FFF]');
final _reKana = RegExp(r'[\u3040-\u30FF]');
final _reHangul = RegExp(r'[\uAC00-\uD7AF\u1100-\u11FF]');
final _reDevanagari = RegExp(r'[\u0900-\u097F]');
final _reArabic = RegExp(r'[\u0600-\u06FF\u0750-\u077F]');

int _count(RegExp r, String t) => r.allMatches(t).length;

Future<String> _mlkit(String path, TextRecognitionScript script) async {
  final rec = TextRecognizer(script: script);
  try {
    final r = await rec.processImage(InputImage.fromFilePath(path));
    return r.text;
  } finally {
    await rec.close();
  }
}

Future<String> _single(String path, OcrLang lang) {
  switch (lang) {
    case OcrLang.latin:
      return _mlkit(path, TextRecognitionScript.latin);
    case OcrLang.chinese:
      return _mlkit(path, TextRecognitionScript.chinese);
    case OcrLang.japanese:
      return _mlkit(path, TextRecognitionScript.japanese);
    case OcrLang.korean:
      return _mlkit(path, TextRecognitionScript.korean);
    case OcrLang.devanagari:
      return _mlkit(path, TextRecognitionScript.devanagiri);
    case OcrLang.arabic:
      return recognizeArabic(path);
    case OcrLang.auto:
      return _auto(path);
  }
}

/// Prova i riconoscitori principali e sceglie quello che trova più caratteri
/// del proprio alfabeto. L'arabo (più lento) viene provato solo se il resto
/// non trova praticamente nulla.
Future<String> _auto(String path) async {
  final latin = await _mlkit(path, TextRecognitionScript.latin);
  final chinese = await _mlkit(path, TextRecognitionScript.chinese);
  final japanese = await _mlkit(path, TextRecognitionScript.japanese);
  final korean = await _mlkit(path, TextRecognitionScript.korean);
  final devanagari = await _mlkit(path, TextRecognitionScript.devanagiri);

  final hasKana = _count(_reKana, japanese) > 0;
  final scored = <MapEntry<int, String>>[
    MapEntry(_count(_reLatin, latin), latin),
    MapEntry(hasKana ? 0 : _count(_reHan, chinese), chinese),
    MapEntry(
      hasKana ? _count(_reKana, japanese) * 2 + _count(_reHan, japanese) : 0,
      japanese,
    ),
    MapEntry(_count(_reHangul, korean), korean),
    MapEntry(_count(_reDevanagari, devanagari), devanagari),
  ]..sort((a, b) => b.key.compareTo(a.key));

  if (scored.first.key >= 8) return scored.first.value;

  try {
    final ar = await recognizeArabic(path);
    if (_count(_reArabic, ar) > scored.first.key) return ar;
  } catch (_) {
    /* Tesseract non disponibile: tieni il miglior risultato */
  }
  return scored.first.value;
}

Future<String> recognizeText(List<String> imagePaths, OcrLang lang) async {
  final buf = StringBuffer();
  for (final path in imagePaths) {
    buf
      ..writeln(await _single(path, lang))
      ..writeln();
  }
  return buf.toString().trim();
}

/// Esegue l'OCR su tutte le pagine e salva il risultato. Non lancia eccezioni:
/// restituisce un messaggio d'errore leggibile, oppure null se è andato tutto bene.
Future<String?> indexDoc(Repository repo, ScanDoc d) async {
  try {
    final paths = [
      for (var i = 0; i < d.pages.length; i++) repo.pageFile(d, i).path,
    ];
    d.ocrText = await recognizeText(paths, d.ocrLang);
    await repo.save(d);
    return null;
  } catch (e) {
    return 'OCR non riuscito (${d.ocrLang.label}): $e';
  }
}
