import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/scan_doc.dart';
import '../services/image_tools.dart';
import '../services/ocr_service.dart';
import '../services/pdf_service.dart';
import '../services/repository.dart';
import '../services/scanner_service.dart';

class DocScreen extends StatefulWidget {
  const DocScreen({super.key, required this.repo, required this.doc});
  final Repository repo;
  final ScanDoc doc;
  @override
  State<DocScreen> createState() => _DocScreenState();
}

class _DocScreenState extends State<DocScreen> {
  late final PageController _pc = PageController();
  int _page = 0;
  int _rev = 0; // forza il ricaricamento delle immagini dopo una modifica
  bool _busy = false;

  ScanDoc get doc => widget.doc;
  Repository get repo => widget.repo;

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _run(Future<void> Function() job) async {
    setState(() => _busy = true);
    try {
      await job();
    } catch (e) {
      _toast('Errore: $e');
    } finally {
      imageCache.clear();
      imageCache.clearLiveImages();
      if (mounted)
        setState(() {
          _busy = false;
          _rev++;
        });
    }
  }

  Future<void> _shareFiles(List<String> paths, {String? text}) async {
    await SharePlus.instance.share(
      ShareParams(files: [for (final p in paths) XFile(p)], text: text),
    );
  }

  Future<void> _filter(ScanFilter f) =>
      _run(() => applyFilter(repo.pageFile(doc, _page), f));
  Future<void> _rotate() => _run(() => rotate90(repo.pageFile(doc, _page)));
  Future<void> _restore() =>
      _run(() => restoreOriginal(repo.pageFile(doc, _page)));

  Future<void> _addPages() async {
    List<String>? paths;
    try {
      paths = await pickPages();
    } catch (e) {
      _toast('Scansione non riuscita: $e');
      return;
    }
    if (paths == null || paths.isEmpty) return;
    final newPaths = paths;
    await _run(() async {
      for (final s in newPaths) {
        await repo.addPage(doc, s);
      }
      await repo.save(doc);
    });
    unawaited(indexDoc(repo, doc));
  }

  Future<void> _deletePage() async {
    if (doc.pages.length == 1) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Eliminare l’ultima pagina?'),
          content: const Text('Verrà eliminato l’intero documento.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Annulla'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Elimina'),
            ),
          ],
        ),
      );
      if (ok == true) {
        await repo.delete(doc);
        if (mounted) Navigator.pop(context);
      }
      return;
    }
    await _run(() async {
      await repo.removePage(doc, _page);
      if (_page >= doc.pages.length) _page = doc.pages.length - 1;
      await repo.save(doc);
    });
    unawaited(indexDoc(repo, doc));
  }

  Future<void> _collage() async {
    var layout = collageLayouts[1];
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) {
          final sheets = (doc.pages.length / layout.perSheet).ceil();
          return AlertDialog(
            title: const Text('Crea collage'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  children: [
                    for (final l in collageLayouts)
                      ChoiceChip(
                        label: Text('${l.perSheet} per foglio'),
                        selected: l == layout,
                        onSelected: (_) => set(() => layout = l),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  '${doc.pages.length} pagine → $sheets foglio/i A4.\n'
                  'Viene creato un nuovo documento: l’originale non cambia.',
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Annulla'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Crea'),
              ),
            ],
          );
        },
      ),
    );
    if (ok != true) return;

    ScanDoc? created;
    await _run(() async {
      final tmp = await getTemporaryDirectory();
      final out = await Directory(
        '${tmp.path}/collage_${DateTime.now().millisecondsSinceEpoch}',
      ).create(recursive: true);
      try {
        final paths = [
          for (var i = 0; i < doc.pages.length; i++) repo.pageFile(doc, i).path,
        ];
        final files = await buildCollages(paths, layout, out);
        final d = await repo.create(files.map((f) => f.path).toList());
        d.name = 'Collage - ${doc.name}';
        d.ocrLang = doc.ocrLang;
        await repo.save(d);
        created = d;
      } finally {
        await out.delete(recursive: true);
      }
    });
    final d = created;
    if (d != null && mounted) {
      unawaited(indexDoc(repo, d));
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DocScreen(repo: repo, doc: d),
        ),
      );
    }
  }

  Future<void> _rename() async {
    final c = TextEditingController(text: doc.name);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rinomina'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Annulla'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Salva'),
          ),
        ],
      ),
    );
    if (name != null && name.isNotEmpty) {
      setState(() => doc.name = name);
      await repo.save(doc);
    }
  }

  Future<void> _sharePdf() => _run(() async {
    final f = await buildPdf(repo, doc);
    await _shareFiles([f.path], text: doc.name);
  });

  Future<void> _shareImages() => _run(() async {
    await _shareFiles([
      for (var i = 0; i < doc.pages.length; i++) repo.pageFile(doc, i).path,
    ]);
  });

  Future<void> _ocrSheet() async {
    final c = TextEditingController(text: doc.ocrText);
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(
          16,
          0,
          16,
          MediaQuery.of(ctx).viewInsets.bottom + 16,
        ),
        child: SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.7,
          child: Column(
            children: [
              Expanded(
                child: TextField(
                  controller: c,
                  maxLines: null,
                  expands: true,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Nessun testo riconosciuto',
                  ),
                ),
              ),
              const SizedBox(height: 12),
              StatefulBuilder(
                builder: (c2, set) => InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Lingua / alfabeto OCR',
                    border: OutlineInputBorder(),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<OcrLang>(
                      value: doc.ocrLang,
                      isExpanded: true,
                      isDense: true,
                      items: [
                        for (final l in OcrLang.values)
                          DropdownMenuItem(value: l, child: Text(l.label)),
                      ],
                      onChanged: (v) async {
                        if (v == null) return;
                        set(() => doc.ocrLang = v);
                        await repo.save(doc);
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: [
                  OutlinedButton.icon(
                    icon: const Icon(Icons.copy),
                    label: const Text('Copia'),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: c.text));
                      _toast('Testo copiato');
                    },
                  ),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.refresh),
                    label: const Text('Rifai OCR'),
                    onPressed: () async {
                      Navigator.pop(ctx);
                      await _run(() async {
                        final err = await indexDoc(repo, doc);
                        if (err != null) _toast(err);
                      });
                      if (mounted) _ocrSheet();
                    },
                  ),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.ios_share),
                    label: const Text('.txt'),
                    onPressed: () async {
                      doc.ocrText = c.text;
                      final f = await buildTxt(doc);
                      await _shareFiles([f.path]);
                    },
                  ),
                  FilledButton.icon(
                    icon: const Icon(Icons.save),
                    label: const Text('Salva'),
                    onPressed: () async {
                      doc.ocrText = c.text;
                      await repo.save(doc);
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onTap: _rename,
          child: Text(doc.name, overflow: TextOverflow.ellipsis),
        ),
        actions: [
          IconButton(
            tooltip: 'Condividi PDF',
            icon: const Icon(Icons.picture_as_pdf_outlined),
            onPressed: _busy ? null : _sharePdf,
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'img') _shareImages();
              if (v == 'col') _collage();
              if (v == 'ren') _rename();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'img',
                child: Text('Condividi come immagini'),
              ),
              PopupMenuItem(value: 'col', child: Text('Crea collage…')),
              PopupMenuItem(value: 'ren', child: Text('Rinomina')),
            ],
          ),
        ],
      ),
      body: Stack(
        children: [
          PageView.builder(
            controller: _pc,
            itemCount: doc.pages.length,
            onPageChanged: (i) => setState(() => _page = i),
            itemBuilder: (_, i) => InteractiveViewer(
              maxScale: 5,
              child: Center(
                child: Image.file(
                  repo.pageFile(doc, i),
                  key: ValueKey('$i-$_rev'),
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ),
          Positioned(
            top: 8,
            right: 12,
            child: Chip(label: Text('${_page + 1} / ${doc.pages.length}')),
          ),
          if (_busy) const Center(child: CircularProgressIndicator()),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            PopupMenuButton<String>(
              tooltip: 'Filtri',
              icon: const Icon(Icons.auto_fix_high),
              enabled: !_busy,
              onSelected: (v) {
                switch (v) {
                  case 'auto':
                    _filter(ScanFilter.auto);
                  case 'gray':
                    _filter(ScanFilter.gray);
                  case 'bw':
                    _filter(ScanFilter.bw);
                  case 'orig':
                    _restore();
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'auto', child: Text('Migliora (auto)')),
                PopupMenuItem(value: 'gray', child: Text('Scala di grigi')),
                PopupMenuItem(value: 'bw', child: Text('Bianco e nero')),
                PopupMenuItem(
                  value: 'orig',
                  child: Text('Ripristina originale'),
                ),
              ],
            ),
            IconButton(
              tooltip: 'Ruota',
              icon: const Icon(Icons.rotate_right),
              onPressed: _busy ? null : _rotate,
            ),
            IconButton(
              tooltip: 'Aggiungi pagine',
              icon: const Icon(Icons.add_a_photo_outlined),
              onPressed: _busy ? null : _addPages,
            ),
            IconButton(
              tooltip: 'Testo (OCR)',
              icon: const Icon(Icons.text_snippet_outlined),
              onPressed: _busy ? null : _ocrSheet,
            ),
            IconButton(
              tooltip: 'Elimina pagina',
              icon: const Icon(Icons.delete_outline),
              onPressed: _busy ? null : _deletePage,
            ),
          ],
        ),
      ),
    );
  }
}
