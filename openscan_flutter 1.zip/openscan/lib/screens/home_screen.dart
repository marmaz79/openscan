import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../models/scan_doc.dart';
import '../services/ocr_service.dart';
import '../services/repository.dart';
import '../services/scanner_service.dart';
import 'doc_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Repository? _repo;
  List<ScanDoc> _docs = [];
  String _query = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _repo = await Repository.open();
    await _load();
  }

  Future<void> _load() async {
    final docs = await _repo!.all();
    if (!mounted) return;
    setState(() {
      _docs = docs;
      _loading = false;
    });
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _createFrom(List<String> paths) async {
    final doc = await _repo!.create(paths);
    unawaited(indexDoc(_repo!, doc).then((_) => _load()));
    await _open(doc);
  }

  Future<void> _scan() async {
    try {
      final paths = await pickPages();
      if (paths == null || paths.isEmpty) return;
      await _createFrom(paths);
    } catch (e) {
      _toast('Scansione non riuscita: $e');
    }
  }

  Future<void> _importGallery() async {
    try {
      final paths = await pickPages(galleryOnly: true);
      if (paths == null || paths.isEmpty) return;
      await _createFrom(paths);
    } catch (e) {
      _toast('Importazione non riuscita: $e');
    }
  }

  Future<void> _open(ScanDoc d) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DocScreen(repo: _repo!, doc: d),
      ),
    );
    await _load();
  }

  Future<void> _confirmDelete(ScanDoc d) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Eliminare il documento?'),
        content: Text(d.name),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Annulla'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Elimina'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await _repo!.delete(d);
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.toLowerCase();
    final shown = q.isEmpty
        ? _docs
        : _docs
              .where(
                (d) =>
                    d.name.toLowerCase().contains(q) ||
                    d.ocrText.toLowerCase().contains(q),
              )
              .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('OpenScan'),
        actions: [
          IconButton(
            tooltip: 'Importa dalla galleria',
            icon: const Icon(Icons.photo_library_outlined),
            onPressed: _loading ? null : _importGallery,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(64),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: SearchBar(
              hintText: 'Cerca nel nome o nel testo (OCR)',
              leading: const Icon(Icons.search),
              elevation: const WidgetStatePropertyAll(0),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _loading ? null : _scan,
        icon: const Icon(Icons.document_scanner_outlined),
        label: const Text('Scansiona'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : shown.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Text(
                  _docs.isEmpty
                      ? 'Nessun documento.\nTocca “Scansiona” per iniziare.'
                      : 'Nessun risultato.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.78,
              ),
              itemCount: shown.length,
              itemBuilder: (_, i) => _DocCard(
                repo: _repo!,
                doc: shown[i],
                onTap: () => _open(shown[i]),
                onLongPress: () => _confirmDelete(shown[i]),
              ),
            ),
    );
  }
}

class _DocCard extends StatelessWidget {
  const _DocCard({
    required this.repo,
    required this.doc,
    required this.onTap,
    required this.onLongPress,
  });
  final Repository repo;
  final ScanDoc doc;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: doc.pages.isEmpty
                  ? const Center(
                      child: Icon(Icons.description_outlined, size: 48),
                    )
                  : Image.file(
                      File(repo.pageFile(doc, 0).path),
                      width: double.infinity,
                      fit: BoxFit.cover,
                      cacheWidth: 400,
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    doc.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${doc.pages.length} pag.',
                    style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
